import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Word } from './Models/Words';

@Injectable({
  providedIn: 'root'
})
export class WordService {
 
  SAVE_WORD = 'word/save'
  GET_ALL_WORDS = 'word/getAll';
  DELETE_WORD = 'word/delete/';
  UPDATE_WORD = 'word/update/';
  CHAR_SEARCH = 'word/get/';
  constructor(private http:HttpClient) { }

  getAll():Observable<any>{
    return  this.http.get(this.GET_ALL_WORDS);
  }

  addBook(payload:Word):Observable<any>{
   return this.http.post(this.SAVE_WORD,payload);
  }

  deteWord(id:any):Observable<any>{
    return this.http.get(this.DELETE_WORD + id);
  }

  addWord(payload: Word): Observable<any> {
    return this.http.post(this.SAVE_WORD, payload);
  }

  updateWord(payload:any,id:any):Observable<any>{
  
   

    console.log(this.UPDATE_WORD + id);
    console.log(payload);
    return this.http.post(this.UPDATE_WORD + id,payload);
   }
   characterSearch(pattern: string): Observable<any> {
    return this.http.get(this.CHAR_SEARCH + pattern);
  }

}
