import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Word } from '../Models/Words';
import { WordService } from '../word.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  words: Array<Word> = [];
  editableWord!: Word;
  showEditForm!: HTMLElement | null;

  sortbyList: any = [
    'Id',
    'Word',
    'Meaning',
    'Part Speech',
    'Example',
    'Last Modified',
  ];

  formSort = new FormGroup({
    sortBy: new FormControl(
      [],
      Validators.required
    ),
  });

  characterForm = new FormGroup({
    character: new FormControl('', Validators.required),
  });

  constructor(private wordService: WordService) {}

  ngOnInit(): void {
    this.showEditForm = document.getElementById('edit-word');
    this.wordService.getAll().subscribe((resp) => {
      console.log(resp);
      this.words = resp;
    });
  }

  characterSearch() {
    this.wordService
      .characterSearch(this.characterForm.value.character)
      .subscribe((resp) => {
        if (resp) {
          this.words = resp;
        }
      });
  }

  sort() {
    switch (this.formSort.value.sortBy) {
      case 'Id':
        this.words.sort(function (a, b) {
          return a.id.valueOf() - b.id.valueOf();
        });
        break;
      case 'Word':
        this.words.sort((a, b) => a.word.localeCompare(b.word));
        break;
      case 'Meaning':
        this.words.sort((a, b) => a.meaning.localeCompare(b.meaning));
        break;
      case 'Part Of Speech':
        this.words.sort((a, b) => a.partOfSpeech.localeCompare(b.partOfSpeech));
        break;
      case 'Example':
        this.words.sort((a, b) => a.example.localeCompare(b.example));
        break;
      case 'Last Modified Time':
        this.words.sort(function (a, b) {
          return (
            new Date(a.lastModifiedTm).valueOf() -
            new Date(b.lastModifiedTm).valueOf()
          );
        });
        break;
    }
  }

  edit(word: Word): void {
    this.editableWord = word;
  }

  delete(word: Word): void {
    this.wordService.deteWord(word.id).subscribe((res: any) => {
      console.log(res);
      if (res) {
        this.words = this.words.filter((oldWord) => word.id != oldWord.id);
      }
    });
  }

  updateWord($event: any): void {
    const wordData = {
      word: $event.word,
      meaning: $event.meaning,
      partOfSpeech: $event.partOfSpeech,
      examole: $event.examole,
      lastModifiedTime: new Date(),
    };
    this.wordService.updateWord(wordData, $event.id).subscribe();
  }
}
