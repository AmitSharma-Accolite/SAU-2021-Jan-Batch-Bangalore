package com.webAppDemo.Dictionay.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.webAppDemo.Dictionay.entities.Word;

public interface DataBaseConnection {
	public Word save(Word word);
	public List<Word> getAll();
	
	public int delete(int id);
	public int update(Word word, int id);
	List<Word> searchByPattern(String character);
}
