package com.webAppDemo.Dictionay.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.webAppDemo.Dictionay.entities.Word;
import com.webAppDemo.Dictionay.service.DataBaseConnection;
import com.webAppDemo.Dictionay.service.WordService;


@Service
public class WordServiceImp implements WordService{

	@Autowired
	DataBaseConnection iWordDao;
	
	@Override
	public Word save(Word word) {
		return iWordDao.save(word)
;
	}
	
	@Override
	public List<Word> getAll(){
		return iWordDao.getAll();
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return iWordDao.delete(id)==1?true:false;
	}

	

	@Override
	public int update(Word word, int id) {
		// TODO Auto-generated method stub
		return iWordDao.update(word,id);
	}

	@Override
	public List<Word> getMatching(String character) {
		// TODO Auto-generated method stub
		return iWordDao.searchByPattern(character);
	}
	


}
