package com.webAppDemo.Dictionay.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webAppDemo.Dictionay.entities.Word;
import com.webAppDemo.Dictionay.service.DataBaseConnection;
import com.webAppDemo.Dictionay.service.WordService;

@RestController
@RequestMapping("word")
public class WordRest {

	@Autowired
	WordService iWordService;
	
	@PostMapping("/save")
	public Word save(@RequestBody Word word) {
	return iWordService.save(word);
	}
	
	@GetMapping("/getAll")
	public List<Word> getAll() {
		System.out.println("inside getAll()");
	return iWordService.getAll();
	}
	
	@GetMapping("/delete/{id}")
	
	public boolean delete(@PathVariable int id) {
		
		return iWordService.delete(id);
		
	}
	@PostMapping("/update/{id}")
	public int update(@RequestBody Word word,@PathVariable int id) {
		return iWordService.update(word,id);
		}
	@GetMapping("/get/{character}")
	public List<Word> getMatching(@PathVariable String character) {
		return iWordService.getMatching(character);
	}
	
}
