package com.webAppDemo.Dictionay.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.webAppDemo.Dictionay.entities.Word;


public interface WordService {
 
	public Word save(Word word);

	public List<Word> getAll();
	
	public boolean delete(int id);

	public int update(Word word, int id);

	public List<Word> getMatching(String character);
}
