package com.webAppDemo.Dictionay.queries;

import com.webAppDemo.Dictionay.table.constant.WordTableConstant;

public class WordQuery {

	
	
	private WordQuery () {
		
	}
	
	//private static final String DELETE_QUERY = "DELETE FROM " +WordTableConstant.TABLE_NAME + "Where"
	public static final String DELETE_QUERY = "DELETE FROM " + WordTableConstant.TABLE_NAME + " WHERE "
			+ WordTableConstant.ID + " =:" + WordTableConstant.ID;
  
	public static final String SELECT_QUERY = " SELECT * FROM " + WordTableConstant.TABLE_NAME;

	public static final String UPDATE_QUERY = "Update " + WordTableConstant.TABLE_NAME + " SET " + WordTableConstant.WORD + "=:" + 
			WordTableConstant.WORD  + "," + WordTableConstant.MEANING+ "=:" + 
			WordTableConstant.MEANING + "," + WordTableConstant.POS + "=:" + 
					WordTableConstant.POS  + "," + WordTableConstant.EXAMPLE  + "=:" + 
							WordTableConstant.EXAMPLE   + "," + WordTableConstant.LAST_MODIFIED_TM + "=:" + 
									WordTableConstant.LAST_MODIFIED_TM +" WHERE "
											+ WordTableConstant.ID + " =:" + WordTableConstant.ID ;

	public static final String MATCHING_QUERY = "SELECT * FROM " + WordTableConstant.TABLE_NAME + " where "
			+ WordTableConstant.WORD + " LIKE :" + WordTableConstant.WORD + " ";
}
