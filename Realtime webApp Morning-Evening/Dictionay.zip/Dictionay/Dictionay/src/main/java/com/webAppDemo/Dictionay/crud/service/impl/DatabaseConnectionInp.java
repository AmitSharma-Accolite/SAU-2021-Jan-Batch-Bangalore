package com.webAppDemo.Dictionay.crud.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.webAppDemo.Dictionay.entities.Word;
import com.webAppDemo.Dictionay.queries.WordQuery;
import com.webAppDemo.Dictionay.service.DataBaseConnection;
import com.webAppDemo.Dictionay.table.constant.WordTableConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Repository
public class DatabaseConnectionInp implements DataBaseConnection {
	
	private static Logger logger = LoggerFactory.getLogger(DatabaseConnectionInp.class);
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public Word save(Word word) {
	final KeyHolder holder = new GeneratedKeyHolder();
	String sql = "INSERT INTO WORDS ( WORD , MEANING , PART_OF_SPEECH , EXAMPLE , CREATION_TM , LAST_MODIFIED_TM ) "
	+ " VALUES ( :WORD , :MEANING , :PART_OF_SPEECH , :EXAMPLE , :CREATION_TM , :LAST_MODIFIED_TM )";
	MapSqlParameterSource srcMap = new MapSqlParameterSource();
	srcMap.addValue("WORD", word.getWord());
	srcMap.addValue("MEANING",word.getMeaning());
	srcMap.addValue("PART_OF_SPEECH",word.getPartOfSpeech());
	srcMap.addValue("EXAMPLE",word.getExample());
	srcMap.addValue("CREATION_TM",word.getCreationTm());
	srcMap.addValue("LAST_MODIFIED_TM",word.getLastModifiedTm());

	namedParameterJdbcTemplate.update(sql, srcMap,
	holder, new String[] {"ID"});
	word.setId(holder.getKey().intValue());
	return word;
	}
	
	@Override
	public List<Word> getAll() {
		
		
	String sql = WordQuery.SELECT_QUERY ;
	
	return namedParameterJdbcTemplate.query(sql, (resultSet, rowNum) -> {
	Word word = new Word();
	word.setId(resultSet.getInt(WordTableConstant.ID));
	word.setCreationTm(resultSet.getDate(WordTableConstant.CREATION_TM));
	word.setExample(resultSet.getString(WordTableConstant.EXAMPLE));
	word.setLastModifiedTm(resultSet.getDate(WordTableConstant.LAST_MODIFIED_TM));
	word.setMeaning(resultSet.getString(WordTableConstant.MEANING));
	word.setPartOfSpeech(resultSet.getString(WordTableConstant.POS));
	word.setWord(resultSet.getString(WordTableConstant.WORD));
	
	return word;
	});
	
	
	}

	@Override
	public int  delete(int id) {
		// TODO Auto-generated method stub
		logger.info(WordQuery.DELETE_QUERY);
		String deleteQuery = WordQuery.DELETE_QUERY ;
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue(WordTableConstant.ID, id);
		return namedParameterJdbcTemplate.update(deleteQuery , srcMap);
		
	}

	@Override
	public int update(Word word,int id) {
		// TODO Auto-generated method stub
		String updateQuery = WordQuery.UPDATE_QUERY;
		
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue(WordTableConstant.ID, id);
		srcMap.addValue(WordTableConstant.WORD, word.getWord());
		srcMap.addValue(WordTableConstant.MEANING, word.getMeaning());
		srcMap.addValue(WordTableConstant.POS , word.getPartOfSpeech());
		srcMap.addValue(WordTableConstant.EXAMPLE , word.getExample());
		srcMap.addValue(WordTableConstant.LAST_MODIFIED_TM , word.getLastModifiedTm());
		return namedParameterJdbcTemplate.update(updateQuery, srcMap);
	}
	@Override
	public List<Word> searchByPattern(String character) {
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue(WordTableConstant.WORD, "%" + character + "%");
		logger.info(WordQuery.MATCHING_QUERY);
		return namedParameterJdbcTemplate.query(WordQuery.MATCHING_QUERY, srcMap, (resultSet, rowNum) -> {
			Word word = new Word();
			word.setId(resultSet.getInt(WordTableConstant.ID));
			word.setCreationTm(resultSet.getDate(WordTableConstant.CREATION_TM));
			word.setExample(resultSet.getString(WordTableConstant.EXAMPLE));
			word.setLastModifiedTm(resultSet.getDate(WordTableConstant.LAST_MODIFIED_TM));
			word.setMeaning(resultSet.getString(WordTableConstant.MEANING));
			word.setPartOfSpeech(resultSet.getString(WordTableConstant.POS));
			word.setWord(resultSet.getString(WordTableConstant.WORD));
			return word;
		});
	}
}
