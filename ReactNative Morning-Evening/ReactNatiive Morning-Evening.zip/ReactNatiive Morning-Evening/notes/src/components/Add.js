import React, { useEffect, useState } from "react";

import { Text, View, TextInput, Button,StyleSheet, } from "react-native";
import { not } from "react-native-reanimated";
import { AsyncStorage } from "react-native";
// import { NavigationEvents } from 'react-navigation';
const Add = ({ route, navigation }) => {
  const { itemId, bucket, receivedValue } = route.params;

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  console.log("ADD screen");

  const addNewNotes = () => {
    console.log("addNewNotes");
    const note = {
      Title: title,
      Description: description,
      date: Date.now(),
    };

    setTitle("");
    setDescription("");
    receivedValue(note);

    navigation.navigate("Home");
  };

  return (
    <View style={styles.container}>
        <Text style={styles.title}>ADD NEW NOTE </Text> 
      <TextInput
        multiline={true}
        style={styles.contentContainer}
        onChangeText={(text) => setTitle(text)}
        value={title}
        placeholder="Enter Title"
      />
      {/* <Text style={styles.title}>Enter Description</Text> */}
      <TextInput 
        multiline={true}
        style={styles.contentContainer}
        onChangeText={(text) => setDescription(text)}
        value={description}
        placeholder="Enter Description"
      />
      <View style={styles.btn}>
      <Button 
        title="save"
        color="orange"
        onPress={() => {
          addNewNotes();
        }}
      />
      </View>
    </View>
  );
};
export default Add;


const styles = StyleSheet.create({
  contentContainer: {
    paddingVertical: 20,
    margin:20,
    fontSize: 18,
    color: "green",
    fontWeight: "600",
    padding: 5,
    
    borderBottomColor:'red',
    borderBottomWidth:5,
  },
  btn :{
     width: "40%",
     marginTop:30,
     borderColor:"black",
     borderRadius:30,
     alignSelf: "center",
     shadowOpacity:12,
},
container: {
  
  height: "100%",
  justifyContent:"center",
  marginTop:20,
  color: "white",
  borderRadius:30,
  borderColor:"red",
  shadowOpacity:10,
},
title: {
  
  alignSelf:"center",
  fontSize: 20,
  color: "black",
  fontWeight: "bold",
  padding: 5,
  
},
paragraph: {
  margin: 24,
  fontSize: 18,
  textAlign: 'center',
},
});
// { height: 40, borderColor: "gray", borderWidth: 1 }
// { height: 40, borderColor: "gray", borderWidth: 1 }