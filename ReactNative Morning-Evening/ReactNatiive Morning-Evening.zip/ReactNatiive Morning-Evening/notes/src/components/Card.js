import React from "react";
import {
  Text,
  Image,
  View,
  TouchableOpacity,
  StyleSheet,
  Button,
} from "react-native";
import { color } from "react-native-reanimated";

// Title:title,
// Description:description,
const Card = (props) => {
  const { data, deleteNotes, index } = props;

  deleteNote = (key) => {
    deleteNotes(key);
  };

  return (
    <TouchableOpacity style={Styles.container} >
      <View style={Styles.header}>
        {/* <Text style={Styles.title}>Title</Text> */}
        <Text  multiline={true} style={Styles.content}>{data.Title}</Text>
      </View>
      <View>
        {/* <Text style={Styles.title}>Description</Text> */}
        <Text  multiline={true} style={Styles.content}>{data.Description}</Text>
      </View>

      <View style={Styles.btn}>
        {/* <Image source={require('./Icons/delete.png')} /> */}
        <Button
          mode="contained"
          title="Delete"
          color="red"
          borderColor="black"
          
          onPress={() => {
            deleteNote(data.date);
          }}
        />
      </View>
    </TouchableOpacity>
  );
};

const Styles = StyleSheet.create({
  title: {
    fontSize: 14,
    color: "black",
    fontWeight: "500",
    padding: 5,
  },
  content: {
    fontSize: 17,
    color: "green",
    fontWeight: "700",
    padding: 5,
  },
 
 
  container: {
    width: "95%",
    height: 160,
     margin:"2%",
    marginVertical: 5,
    color: "white",
    borderRadius:10,
    borderColor:"red",
    borderBottomColor:'orange',
    borderBottomWidth:1.5,
  },
  header: {
    flexDirection: "row",
    justifyContent: "center",
    alignContent: "center",
  },
  btn: {
      marginTop:20,
      height:20,
    alignSelf: "flex-end",
    width: "40%",
    margin: 5,
    backgroundColor: "yellow",
    borderColor: "black",
    borderRadius: 20,
  },
});

export default Card;
