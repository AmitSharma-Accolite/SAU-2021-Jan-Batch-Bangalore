import React, { useEffect, useState } from "react";
import { Text, TextInput, View, Button, StyleSheet } from "react-native";
import { AsyncStorage } from "react-native";
const Login = ({ navigation }) => {
  const [userName, setUserName] = React.useState("");

  useEffect(() => {
    checkCredential();
  }, []);

  setCredential = async () => {
    await AsyncStorage.setItem("userName", userName);
    navigation.navigate("Home");
  };

  const checkCredential = async () => {
    const storeUserName = AsyncStorage.getItem("username");
    if (storeUserName) {
      navigation.navigate("Home");
    }
  };

  return (
    <View style={styles.Block} >
    <View style={styles.Container} >
      <TextInput
        style={styles.contentContainer}
        onChangeText={(text) => setUserName(text)}
        value={userName}
        placeholder="UserName"
      />

      <View style={styles.btn}>
        <Button onPress={setCredential} title="Login" color="#841584" />
      </View>
      {/* <Text>Hello Login </Text> */}
    </View>
    </View>
  );
};
export default Login;

const styles = StyleSheet.create({
  
  Block :{
    height: "100%",
    width:"100%",
    

  },
  Container:{
    height: "100%",
    justifyContent:"center",
    alignSelf:"center",
    width:"80%",
    borderColor:"white",
   },
  contentContainer: {
    height: 50,
    width: "100%",
    borderColor: "blue",
    borderWidth: 2,
    marginBottom: 20,
    color:"black",
    fontSize: 18,
    color: "green",
    fontWeight: "600",
    padding: 5,
  },
  btn: {
    width: "40%",

    borderColor: "black",
    borderRadius: 30,
    alignSelf: "flex-end",
    shadowOpacity: 12,
  },
});
