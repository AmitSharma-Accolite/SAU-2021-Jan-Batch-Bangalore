import React, { useEffect, useState } from "react";
import { render } from "react-dom";
import { Button, Text, View, StyleSheet, ScrollView ,FlatList} from "react-native";
import { AsyncStorage } from "react-native";
import Card from "./Card";

const Home = (props) => {
  const { navigation } = props;
  [bucket, setbucket] = useState([{}]);

  // addNotes = (note) =>{
  //   console.log("addcall");
  //      bucket.push(note);
  //      console.log(bucket);
  // }
  useEffect(() => {
    // console.log("inside useEffect");
    addList();
  }, []);

  addList = async () => {
    console.log("inseide AddList");
    try {
      updatedBucket = await AsyncStorage.getItem("notes");
      if (updatedBucket !== null) {
        // We have data!!
        setbucket(JSON.parse(updatedBucket));
        console.log(JSON.parse(updatedBucket));
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  receivedValue = async (note) => {
    const newBucket = [...bucket, note];

    setbucket(newBucket);
    //  console.log(note);

    try {
      await AsyncStorage.setItem("notes", JSON.stringify(newBucket));
    } catch (error) {
      // Error saving data
    }
    console.log("hello");
  };

  deleteNotes = async (key) => {
    console.log("Delete Notes function");
    const updatedBucket = bucket.filter((item) => item.date != key);
    setbucket(updatedBucket);
    try {
      await AsyncStorage.setItem("notes", JSON.stringify(updatedBucket));
    } catch (error) {
      // Error saving data
    }
  };
  return (
    <View>
      <View style={styles.btn}>
      <Button
        onPress={() =>
          navigation.navigate("Add", {
            itemId: 20,
            bucket: bucket,
            receivedValue: receivedValue,
          })
        }
        title ="ADD" 
        color="orange"
      />
      </View>

      {/* {bucket.map((item, index) => {
        return (
          <ScrollView style={styles.container}
            contentContainerStyle={styles.contentContainer}
            key={item.date}>
            <Card data={item} deleteNotes={deleteNotes} />
          </ScrollView>
        );
      })} */}
    
   <FlatList style={styles.container}
                data={bucket}
                renderItem={({ item }) =>  <Card data={item} deleteNotes={deleteNotes} />}
                keyExtractor={(item) => item.date}
                initialNumToRender={5}
            />
      
    </View>
  );
};
export default Home;

const styles = StyleSheet.create({
  contentContainer: {
    paddingVertical: 20,
    marginTop:20,
  },
  btn :{
     width: "40%",
     margin:5,
     borderColor:"black",
     borderRadius:30,
     alignSelf: "flex-end",
     shadowOpacity:12,
},
container: {
  

  marginTop:20,
  margin: 5,
  color: "white",
  borderRadius:30,
  borderColor:"red",
  shadowOpacity:10,
},
});
